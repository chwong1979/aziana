# Aziana — marketing website

Static marketing site for **Aziana**, Asian fusion dining at Bobby's Marina, Philipsburg, Sint Maarten.

- **Source of truth:** this repo. Pushes to `main` auto-deploy via a Git-connected Cloudflare Pages project.
- **Build:** none — self-contained static site. Pages **output directory = repository root**.
- **Entry:** `index.html` (inline CSS, Google Fonts via CDN). Assets in `images/`, menu in `menus/`, logo `Aziana_logo.png`. All asset paths are relative.
- **Version:** v0.5.0 (see the `VERSION:` comment in `index.html`).

## Deploy (Cloudflare Pages, Git-connected)

Connect this repo - Production branch `main` - Framework preset: **None** - Build command: *(empty)* - Build output directory: **`/`**. No environment variables.

Deployment note: this repository is intended as the source of truth for the Aziana website. If Cloudflare is serving from a Worker or Pages project, keep the dashboard target pointed at this repo/main branch so future updates stay in one place.
